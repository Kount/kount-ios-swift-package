Swift Package Manager Client SDK
====================

Kount's Swift Package Manager (SPM) SDK helps integrate Kount's fraud fighting solution into
your iOS app.

## Installation

Download the [Kount Swift iOS SDK](https://github.com/Kount/kount-ios-swift-package), and then follow the [Developer documentation](https://developer.kount.com/hc/en-us/articles/6212983250580) for the complete integration instructions.
