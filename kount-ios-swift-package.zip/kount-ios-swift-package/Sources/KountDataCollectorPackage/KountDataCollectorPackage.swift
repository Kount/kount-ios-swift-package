struct KountDataCollectorPackage {
    var text = "Hello, World!"
}
